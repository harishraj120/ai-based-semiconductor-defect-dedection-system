# WaferIQ — AI-Based Semiconductor Defect Detection

Academic web prototype implementing the supplied project specification.

## Run
Backend:
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Frontend:
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173. API docs: http://127.0.0.1:8000/docs

The prototype has a React/TypeScript interface and FastAPI backend. Sample wafer inspections are DEMO results, not trained AI predictions. REAL AI mode remains unavailable until a trained model, matching preprocessing, and validated class mapping are supplied. WM-811K is not bundled; import an authorized dataset copy for actual research.
