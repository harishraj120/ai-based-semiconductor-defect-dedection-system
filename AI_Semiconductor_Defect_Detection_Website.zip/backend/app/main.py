from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from pathlib import Path
from datetime import datetime, timezone
from io import BytesIO
import sqlite3, uuid, time
import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

DB=Path(__file__).resolve().parent.parent/"waferiq.sqlite3"
CLASSES=["Normal","Center","Donut","Edge-Loc","Edge-Ring","Loc","Random","Scratch","Near-full"]
app=FastAPI(title="WaferIQ Semiconductor Inspection API",version="1.0.0")
app.add_middleware(CORSMiddleware,allow_origins=["http://localhost:5173","http://127.0.0.1:5173"],allow_methods=["*"],allow_headers=["*"])
def db():
    c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c
def init():
    with db() as c:
        c.execute("CREATE TABLE IF NOT EXISTS inspections(id TEXT PRIMARY KEY,wafer_id TEXT,pattern TEXT,status TEXT,confidence REAL,defect_percentage REAL,defect_dies INTEGER,processing_ms INTEGER,mode TEXT,created_at TEXT,filename TEXT,disclaimer TEXT)")
init()
class Sample(BaseModel):
    pattern:str="Normal"
    mode:str="DEMO"
@app.get("/health")
def health():return {"status":"ok","service":"waferiq-api","model":"not-configured","mode":"DEMO"}
@app.get("/api/inspections")
def history():
    with db() as c: rows=c.execute("SELECT * FROM inspections ORDER BY created_at DESC LIMIT 500").fetchall()
    return {"items":[dict(r) for r in rows]}
def save(pattern,filename,mode,pct,dies,confidence,elapsed):
    rid="WI-"+uuid.uuid4().hex[:10].upper()
    status="NORMAL" if pattern=="Normal" else "DEFECT"
    disclaimer="DEMO result from a built-in sample or heuristic. It is not a trained-model prediction."
    row=(rid,"WFR-"+uuid.uuid4().hex[:7].upper(),pattern,status,confidence,pct,dies,elapsed,mode,datetime.now(timezone.utc).isoformat(),filename,disclaimer)
    with db() as c:c.execute("INSERT INTO inspections VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",row)
    keys=["id","wafer_id","pattern","status","confidence","defect_percentage","defect_dies","processing_ms","mode","created_at","filename","disclaimer"]
    return dict(zip(keys,row))
@app.post("/api/inspect/sample")
def sample(req:Sample):
    if req.pattern not in CLASSES:raise HTTPException(400,"Unsupported pattern")
    if req.mode!="DEMO":raise HTTPException(409,"REAL AI is unavailable until a trained checkpoint and validated class mapping are configured.")
    start=time.perf_counter()
    pct=[0,3.4,18.2,7.8,22.1,5.6,11.7,9.2,68][CLASSES.index(req.pattern)]
    dies=int(pct*529/100);confidence=96.2 if req.pattern=="Normal" else 91.4-(CLASSES.index(req.pattern)*7%13)
    time.sleep(.15)
    return save(req.pattern,"built-in-sample-"+req.pattern,"DEMO",pct,dies,confidence,max(1,int((time.perf_counter()-start)*1000)))
@app.post("/api/inspect")
async def inspect(file:UploadFile=File(...),pattern_hint:str=Form("Normal")):
    if pattern_hint not in CLASSES:pattern_hint="Normal"
    data=await file.read()
    if not data:raise HTTPException(400,"Empty upload")
    if len(data)>20*1024*1024:raise HTTPException(413,"File exceeds 20 MB")
    start=time.perf_counter()
    if file.filename.lower().endswith(".csv"):
        try:
            arr=np.genfromtxt(BytesIO(data),delimiter=",")
            if arr.ndim!=2 or not arr.size:raise ValueError()
            valid=arr[np.isfinite(arr)];pct=float(np.mean(valid>0)*100) if valid.size else 0;dies=int(np.sum(valid>0))
        except Exception:raise HTTPException(400,"CSV must contain a numeric 2D wafer-map matrix")
    else:
        try:
            im=ImageOps.exif_transpose(Image.open(BytesIO(data))).convert("L")
            if im.width<16 or im.height<16:raise HTTPException(400,"Image dimensions too small")
            im.thumbnail((256,256));arr=np.asarray(im,dtype=np.float32);pct=float(np.mean(arr<70)*100);dies=int(pct*529/100)
        except UnidentifiedImageError:raise HTTPException(400,"Invalid image file")
    elapsed=max(1,int((time.perf_counter()-start)*1000))
    # Image appearance alone cannot establish defect semantics; hint is a demonstration-only label.
    return save(pattern_hint,file.filename,"DEMO",pct,dies,75.0,elapsed)
@app.get("/api/reports/{inspection_id}.pdf")
def report(inspection_id:str):
    with db() as c:r=c.execute("SELECT * FROM inspections WHERE id=?",(inspection_id,)).fetchone()
    if not r:raise HTTPException(404,"Inspection not found")
    r=dict(r);out=BytesIO();p=canvas.Canvas(out,pagesize=A4);w,h=A4
    p.setFillColorRGB(.03,.09,.16);p.rect(0,h-110,w,110,fill=1,stroke=0)
    p.setFillColorRGB(.4,.75,1);p.setFont("Helvetica-Bold",22);p.drawString(42,h-55,"WAFERIQ")
    p.setFillColorRGB(1,1,1);p.setFont("Helvetica",10);p.drawString(42,h-78,"SEMICONDUCTOR WAFER INSPECTION REPORT")
    y=h-145;p.setFillColorRGB(.08,.14,.21);p.setFont("Helvetica-Bold",14);p.drawString(42,y,"Inspection summary");y-=28
    fields=[("Inspection ID",r["id"]),("Wafer ID",r["wafer_id"]),("Timestamp",r["created_at"]),("Mode",r["mode"]),("Predicted pattern",r["pattern"]),("Condition",r["status"]),("Confidence",f'{r["confidence"]:.1f}%'),("Defect area",f'{r["defect_percentage"]:.1f}%'),("Suspicious cells (estimate)",r["defect_dies"]),("Processing time",f'{r["processing_ms"]} ms')]
    for k,v in fields:
        p.setFillColorRGB(.4,.48,.57);p.setFont("Helvetica-Bold",9);p.drawString(45,y,k)
        p.setFillColorRGB(.08,.14,.21);p.setFont("Helvetica",9);p.drawString(190,y,str(v)[:90]);y-=20
    y-=12;p.setFillColorRGB(.72,.45,.12);p.setFont("Helvetica-Bold",10);p.drawString(45,y,"SCIENTIFIC DISCLAIMER");y-=18
    p.setFillColorRGB(.25,.3,.36);p.setFont("Helvetica",9)
    for line in [r["disclaimer"],"Academic demonstration only; not a manufacturing release decision.","Actual model metrics require a trained model and held-out labelled test data."]:
        p.drawString(45,y,line[:110]);y-=16
    p.save();out.seek(0)
    return StreamingResponse(out,media_type="application/pdf",headers={"Content-Disposition":f'attachment; filename="{inspection_id}.pdf"'})
