# Architecture

React + TypeScript frontend -> FastAPI REST API -> validation -> demonstration inspection adapter -> SQLite inspection history -> PDF report generator.

## Real AI integration requirements
A production adapter must load a versioned checkpoint, reproduce training preprocessing, validate class-index mapping, support unknown-pattern rejection, and report calibrated confidence only if calibration has been performed. Wafer-map pixel encodings must be documented.

## Current implementation
Implemented: navigation, sample wafer maps, upload validation, demo inspection, SQLite history, PDF reports, CSV export, dashboard charts.
Scaffolded UI: dataset manager, preprocessing controls, augmentation controls, architecture selection, training configuration, localization capability explanation, evaluation readiness, administration.
Not production implemented: authentication, WM-811K training pipeline, genuine CNN inference, Grad-CAM, PostgreSQL/Redis, production RBAC and deployment hardening.
